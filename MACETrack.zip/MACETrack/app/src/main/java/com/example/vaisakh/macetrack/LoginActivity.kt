package com.example.vaisakh.macetrack

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var button1 =findViewById<Button>(R.id.Button1)
        button1.setOnClickListener(View.OnClickListener{
            view -> login()
        })

        var button2 =findViewById<Button>(R.id.button2)

        button2.setOnClickListener{ var i=Intent(this,Activity_signup::class.java)
            startActivity(i)}

    }

    private fun login(){
        var status:String=if(usertext.text.toString().equals("Shah")){

            var i= Intent(this,MainActivity::class.java)
            startActivity(i)

            "Validated"
        }

        else if(usertext.text.toString().equals("Asif")){

            var i= Intent(this,MainActivity::class.java)
            startActivity(i)
            "Validated"

        }
        else{

            "failed"
        }

        Toast.makeText(this,status,Toast.LENGTH_SHORT).show()





    }


}
